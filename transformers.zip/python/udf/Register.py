from pyspark.sql.types import *
from DateTime import DateTime
from String import String
from List import List
from Math import Math
from Html import Html
from Xml import Xml
from Url import Url

class Register:

    @staticmethod
    def registerAllUDFs(sqlC):
        Register.registerDateTimeUDFs(sqlC)
        Register.registerHtmlUDFs(sqlC)
        Register.registerListUDFs(sqlC)
        Register.registerMathUDFs(sqlC)
        Register.registerStringUDFs(sqlC)
        Register.registerUrlUDFs(sqlC)
        Register.registerXmlUDFs(sqlC)

    @staticmethod
    def registerDateTimeUDFs(sc):
        sc.registerFunction("milliSeconds", DateTime.milliSeconds, IntegerType())
        sc.registerFunction("addYears", DateTime.addYears, TimestampType())
        sc.registerFunction("addMonths", DateTime.addMonths, TimestampType())
        sc.registerFunction("addWeeks", DateTime.addWeeks, TimestampType())
        sc.registerFunction("addDays", DateTime.addDays, TimestampType())
        sc.registerFunction("addHours", DateTime.addHours, TimestampType())
        sc.registerFunction("addMinutes", DateTime.addMinutes, TimestampType())
        sc.registerFunction("addSeconds", DateTime.addSeconds, TimestampType())
        sc.registerFunction("dateInYears", DateTime.dateInYears, FloatType())
        sc.registerFunction("dateInMonths", DateTime.dateInMonths, FloatType())
        sc.registerFunction("dateInWeeks", DateTime.dateInWeeks, FloatType())
        sc.registerFunction("dateInDays", DateTime.dateInDays, FloatType())
        sc.registerFunction("timeInHours", DateTime.timeInHours, FloatType())
        sc.registerFunction("timeInMinutes", DateTime.timeInMinutes, FloatType())
        sc.registerFunction("timeInSeconds", DateTime.timeInSeconds, LongType())
        sc.registerFunction("minutesDifference", DateTime.minutesDifference, FloatType())
        sc.registerFunction("secondsDifference", DateTime.secondsDifference, FloatType())
        sc.registerFunction("hoursDifference", DateTime.hoursDifference, FloatType())
        sc.registerFunction("daysDifference", DateTime.daysDifference, FloatType())
        sc.registerFunction("weeksDifference", DateTime.weeksDifference, FloatType())
        sc.registerFunction("yearsDifference", DateTime.yearsDifference, FloatType())
        sc.registerFunction("dateBefore", DateTime.dateBefore, BooleanType())
        sc.registerFunction("timeBefore", DateTime.timeBefore, BooleanType())
        sc.registerFunction("monthsDifference", DateTime.monthsDifference, IntegerType())
        sc.registerFunction("day", DateTime.day, IntegerType())
        sc.registerFunction("month", DateTime.month, IntegerType())
        sc.registerFunction("year", DateTime.year, IntegerType())
        # sc.registerFunction("now", DateTime.now, TimestampType())
        sc.registerFunction("dayName", DateTime.dayName, StringType())
        sc.registerFunction("monthName", DateTime.monthName, StringType())
        sc.registerFunction("weekdayName", DateTime.weekdayName, StringType())

    @staticmethod
    def registerHtmlUDFs(sc):
        sc.registerFunction("htmlExtractTag", Html.htmlExtractTag, StringType())
        sc.registerFunction("htmlTagValue", Html.htmlTagValue, StringType())
        sc.registerFunction("htmlExtractTags", Html.htmlExtractTags, ArrayType(StringType()))
        sc.registerFunction("htmlAttrValue", Html.htmlAttrValue, StringType())
        sc.registerFunction("htmlRemoveMarkup", Html.htmlRemoveMarkup, StringType())

    @staticmethod
    def registerListUDFs(sc):
        sc.registerFunction("countEqual", List.countEqual, LongType())
        sc.registerFunction("countGreaterThan", List.countGreaterThan, LongType())
        sc.registerFunction("countLessThan", List.countLessThan, LongType())
        sc.registerFunction("countNotEqual", List.countNotEqual, LongType())
        sc.registerFunction("countNulls", List.countNulls, LongType())
        sc.registerFunction("countNotNulls", List.countNotNulls, LongType())
        sc.registerFunction("firstIndex", List.firstIndex, LongType())
        sc.registerFunction("firstNonNull", List.firstNonNull, StringType())
        sc.registerFunction("firstNonNullIndex", List.firstNonNullIndex, LongType())
        sc.registerFunction("lastIndex", List.lastIndex, LongType())
        sc.registerFunction("lastNonNull", List.lastNonNull, StringType())
        sc.registerFunction("lastNonNullIndex", List.lastNonNullIndex, LongType())
        sc.registerFunction("maxN", List.maxN, DoubleType())
        sc.registerFunction("minN", List.minN, DoubleType())

    @staticmethod
    def registerMathUDFs(sc):
        sc.registerFunction("fact", Math.fact, LongType())
        sc.registerFunction("even", Math.even, IntegerType())
        sc.registerFunction("greatestCommonDenominator", Math.greatestCommonDenominator, DoubleType())
        sc.registerFunction("leastCommonMultiple", Math.leastCommonMultiple, DoubleType())
        sc.registerFunction("quotient", Math.quotient, DoubleType())
        sc.registerFunction("percentage", Math.percentage, DoubleType())
        sc.registerFunction("odd", Math.odd, IntegerType())
        sc.registerFunction("arcCosH", Math.arcCosH, DoubleType())
        sc.registerFunction("arcSinH", Math.arcSinH, DoubleType())
        sc.registerFunction("arcTanH", Math.arcTanH, DoubleType())
        sc.registerFunction("fracOf", Math.fracOf, DoubleType())
        sc.registerFunction("testBit", Math.testBit, IntegerType())
        sc.registerFunction("intBitCount", Math.intBitCount, IntegerType())
        sc.registerFunction("intLeastBit", Math.intLeastBit, IntegerType())
        sc.registerFunction("intBitLength", Math.intBitLength, IntegerType())

    @staticmethod
    def registerStringUDFs(sc):
        sc.registerFunction("validText", String.validText, BooleanType())
        sc.registerFunction("allButFirst", String.allButFirst, StringType())
        sc.registerFunction("allButLast", String.allButLast, StringType())
        sc.registerFunction("wordCount", String.wordCount, IntegerType())
        sc.registerFunction("endString", String.endString, StringType())
        sc.registerFunction("startString", String.startString, StringType())
        sc.registerFunction("clean", String.clean, StringType())
        sc.registerFunction("patternSliceItem", String.patternSliceItem, StringType())
        sc.registerFunction("sliceItem", String.sliceItem, StringType())
        sc.registerFunction("getMatches", String.getMatches, ArrayType(StringType()))
        sc.registerFunction("getMatch", String.getMatch, StringType())
        sc.registerFunction("getGroupMatches", String.getGroupMatches, ArrayType(StringType()))
        sc.registerFunction("getGroupMatch", String.getGroupMatch, StringType())
        sc.registerFunction("substitute", String.substitute, StringType())
        sc.registerFunction("search", String.search, IntegerType())
        sc.registerFunction("slice", String.slice, ArrayType(StringType()))
        sc.registerFunction("patternSlice", String.patternSlice, ArrayType(StringType()))
        sc.registerFunction("isUpperCode", String.isUpperCode, BooleanType())
        sc.registerFunction("isAlphaCode", String.isAlphaCode, BooleanType())
        sc.registerFunction("isNumberCode", String.isNumberCode, BooleanType())
        sc.registerFunction("isLowerCode", String.isLowerCode, BooleanType())
        sc.registerFunction("lastChar", String.lastChar, StringType())
        sc.registerFunction("alphabeticallyBefore", String.alphabeticallyBefore, BooleanType())
        sc.registerFunction("stripChar", String.stripChar, StringType())
        sc.registerFunction("locChar", String.locChar, IntegerType())
        sc.registerFunction("locCharBack", String.locCharBack, IntegerType())
        sc.registerFunction("isSubStringCount", String.isSubStringCount, IntegerType())
        sc.registerFunction("countSubString", String.countSubString, IntegerType())
        sc.registerFunction("hasMidString", String.hasMidString, IntegerType())
        sc.registerFunction("hasSubString", String.hasSubString, IntegerType())
        sc.registerFunction("skipChar", String.skipChar, IntegerType())
        sc.registerFunction("skipCharBack", String.skipCharBack, IntegerType())
        sc.registerFunction("soundexDifference", String.soundexDifference, IntegerType())
        sc.registerFunction("chomp", String.chomp, StringType())
        sc.registerFunction("sha1", String.sha1, StringType())

    @staticmethod
    def registerUrlUDFs(sc):
        sc.registerFunction("urlFragment", Url.urlFragment, StringType())
        sc.registerFunction("urlHost", Url.urlHost, StringType())
        sc.registerFunction("urlPath", Url.urlPath, StringType())
        sc.registerFunction("urlPort", Url.urlPort, IntegerType())
        sc.registerFunction("urlQuery", Url.urlQuery, StringType())
        sc.registerFunction("urlParam", Url.urlParam, StringType())
        sc.registerFunction("urlScheme", Url.urlScheme, StringType())
        sc.registerFunction("urlGet", Url.urlGet, StructType())
        sc.registerFunction("urlGetHeader", Url.urlGetHeader, StringType())
        sc.registerFunction("urlGetContent", Url.urlGetContent, StringType())

    @staticmethod
    def registerXmlUDFs(sc):
        sc.registerFunction("xmlExtractTag", Xml.xmlExtractTag, StringType())
        sc.registerFunction("xmlTagValue", Xml.xmlTagValue, StringType())
        sc.registerFunction("xmlExtractTags", Xml.xmlExtractTags, ArrayType(StringType()))
        sc.registerFunction("xmlAttrValue", Xml.xmlAttrValue, StringType())
