class Constants:
    PERCENTAGE = 100.0
    NUM_TWO = 2
    NUM_ZERO = 0
    NUM_ONE = 1
    REGEX_WORD_DELIMITER = "[^a-zA-Z0-9']+"
    NON_PRINT_CHARS_PY = "[\x00-\x1F\x7F]"
    REGEX_CHARS_TO_ESCAPE = "([+|()\\[\\]{}])"
    UNITS_YEARS = "years"
    UNITS_WEEKS = "weeks"
    UNITS_MONTHS = "months"
    UNITS_DAYS = "days"
    UNITS_HOURS = "hours"
    UNITS_MINUTES = "minutes"
    UNITS_SECONDS = "seconds"
    UNITS_MILLISECONDS = "milliseconds"
    FLOAT_FMT = '%.3f'
