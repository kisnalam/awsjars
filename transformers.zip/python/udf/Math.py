from math import floor
from math import factorial
from math import fabs
from math import log
from math import sqrt
from math import copysign
from Constants import Constants

class Math:

    def __init__(self):
        pass


    @staticmethod
    def fact(n):
        """Returns position of char if the give char is found in give string else -1
        :param text: input number
        :rtype : returns number
        """
        return factorial(n)


    @staticmethod
    def even(value):
        """The method Even is a Spark UDF for calculating the next even number
        :param text: input number
        :rtype : returns number
        """
        temp = int(round(value))
        if temp % Constants.NUM_TWO == Constants.NUM_ZERO:
            return temp
        else:
            return temp + Constants.NUM_ONE


    @staticmethod
    def greatestCommonDenominator(value1, value2):
        """The method greatestCommonDenominator is a Spark UDF for calculating the
        :param text: input numbers
        :rtype : returns number
        """
        if value2 == 0:
            return value1
        else:
            return Math.greatestCommonDenominator(value2, value1 % value2)


    @staticmethod
    def leastCommonMultiple(value1, value2):
        """The method leastCommonMultiple is a Spark UDF for calculating the LeastCommonMultiple of two numbers
        :param text: input numbers
        :rtype : returns number
        """
        return (value1 * value2) / Math.greatestCommonDenominator(value1, value2)


    @staticmethod
    def quotient(value1, value2):
        """The method quotient is a Spark UDF for calculating the Quotient of two numbers
        :param text: input numbers
        :rtype : returns number
        """
        return floor(value1 / value2)

    @staticmethod
    def percentage(numerator, denominator):
        """ Returns the percentage from the numerator and denominator provided.
        :rtype : numeric
        :param numerator: input for numerator
        :param denominator: input for denominator
        :return: percentage
        """
        return float((float(numerator) / float(denominator)) * Constants.PERCENTAGE)

    @staticmethod
    def odd(value):
        """ Rounds a number up to the nearest odd number.
        :param value: input to get nearest odd number.
        :return: odd number
        """
        temp = int(round(value))
        if (fabs(temp) % Constants.NUM_TWO) == Constants.NUM_ONE:
            return temp
        else:
            return temp + Constants.NUM_ONE

    @staticmethod
    def arcCosH(d):
        """
        Returns inverse hyperbolic cosine of the given double argument
        :param d: input double value
        :return: arc cosh of given double value
        """
        return log(d + sqrt(d * d - 1.0))

    @staticmethod
    def arcSinH(d):
        """
        Returns inverse hyperbolic sine of the given double argument
        :param d: input double value
        :return: arc sinh of given double value
        """
        return log(d + sqrt(d * d + 1.0))

    @staticmethod
    def arcTanH(d):
        """
        Returns inverse hyperbolic tan of the given double argument
        :param d: input double value
        :return: arc tanh of given double value
        """
        return 0.5 * log((1.0 + d) / (1.0 - d))

    @staticmethod
    def fracOf(d):
        """
        Returns fraction part of a given double argument
        :param d: input double value
        :return: fraction part of the input double value
        """
        return copysign(1, d) * (d - floor(d))

    @staticmethod
    def __bit_count(int_val, bit):
        bit_count = 0
        for i in range(int_val.bit_length()):
            if Math.testBit(int_val, i) == bit:
                bit_count += 1
        return bit_count

    @staticmethod
    def testBit(int_val, offset):
        return int_val & (1 << offset) > 0

    @staticmethod
    def intBitCount(num):
        """
        Counts the number of 1 or 0 bits in the two's-complement representation of input long.
        If the value is non-negative, returns the number of 1 bits. If the value is negative, it is
        the number of 0 bits. It is always the case that intBitCount(LONG) = intBitCount(-(LONG+1)).
        :param num: input long value
        :return: the number of 1 or 0 bits in the two's complement representation of input
        """
        if num >= 0:
            return Math.__bit_count(num, True)
        else:
            return Math.__bit_count(num, False)

    @staticmethod
    def intLeastBit(num):
        """
        Returns the bit position of least-significant bit set in the supplied long value.
        The return value is the highest power of 2 by which supplied long divides exactly.
        :param num: input long value
        :return: bit position of the least-significant bit set in the long input. If the input
                 value is 0, 63 is returned, assuming that a number is represented by 64 bits
        """
        if num == 0:
            return 63
        else:
            for i in range(num.bit_length()):
                if Math.testBit(num, i):
                    return i

    @staticmethod
    def intBitLength(num):
        """
        Returns the length in bits of input long as a two's-complement integer. That is, the
        return value N will be the smallest number such that input < (1 << N) if input >= 0;
        input >= (1 << N) if input < 0. If input is non-negative, then the representation of
        input as an unsigned integer requires a field of at least N bits. Alternatively, a
        minimum of N+1 bits is required to represent input as a signed number, regardless of
        its sign.
        :param num: input long value
        :return: length in bits of the two's complement representation of input long
        """
        if num == 0:
            return 1
        elif num < 0:
            new_num = -1 - num
            return new_num.bit_length()
        else:
            return num.bit_length()
