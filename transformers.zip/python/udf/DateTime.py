from dateutil.relativedelta import relativedelta
from datetime import date, datetime
from Constants import Constants
import calendar as cal
from decimal import Decimal
from time import gmtime
import math

class DateTime:
    def __init__(self):
        pass

    _MS_PER_SEC = 1000L
    _S_PER_MIN = 60
    _S_PER_HR = 60 * _S_PER_MIN
    _DAYS_PER_WK = 7
    _DAYS_PER_YR = 365.25
    _DAYS_PER_MONTH = 30.4375
    _S_PER_DAY = 24 * _S_PER_HR
    _S_PER_WEEK = _DAYS_PER_WK * _S_PER_DAY
    _S_PER_YR = _DAYS_PER_YR * _S_PER_DAY
    _S_PER_MONTH = _DAYS_PER_MONTH * _S_PER_DAY
    _MS_PER_MIN = 60 * _MS_PER_SEC
    _MS_PER_HR = 60 * _MS_PER_MIN
    _MS_PER_DAY = 24 * _MS_PER_HR
    _MAX_CF_SECONDS = 157722624424800
    _MIN_CF_SECONDS = -157850104212564

    @staticmethod
    def milliSeconds(date_time):
        """ Extracts milliseconds from the date time provided.
        :param date_time: input for datetime
        :return: milliseconds.
        """
        if type(date_time) is date:
            return Constants.NUM_ZERO
        else:
            return date_time.microsecond // DateTime._MS_PER_SEC

    @staticmethod
    def addYears(date_time, value):
        """ Adds given number of years to the date/datetime provided.
        :param date_time: input for date/datetime.
        :return: date/datetime
        """
        return DateTime._updateDateTime(date_time, value, Constants.UNITS_YEARS)

    @staticmethod
    def addMonths(date_time, value):
        """ Adds given number of months to the date/datetime provided.
        :param date_time: input for date/datetime.
        :return: date/datetime
        """
        return DateTime._updateDateTime(date_time, value, Constants.UNITS_MONTHS)

    @staticmethod
    def addWeeks(date_time, value):
        """ Adds given number of weeks to the date/datetime provided.
        :param date_time: input for date/datetime.
        :return: date/datetime
        """
        return DateTime._updateDateTime(date_time, value, Constants.UNITS_WEEKS)

    @staticmethod
    def addDays(date_time, value):
        """ Adds given number of days to the date/datetime provided.
        :param date_time: input for date/datetime.
        :return: date/datetime
        """
        return DateTime._updateDateTime(date_time, value, Constants.UNITS_DAYS)

    @staticmethod
    def addHours(date_time, value):
        """ Adds given number of hours to the date/datetime provided.
        :param date_time: input for date/datetime.
        :return: date/datetime
        """
        return DateTime._updateDateTime(date_time, value, Constants.UNITS_HOURS)

    @staticmethod
    def addMinutes(date_time, value):
        """ Adds given number of minutes to the date/datetime provided.
        :param date_time: input for date/datetime.
        :return: date/datetime
        """
        return DateTime._updateDateTime(date_time, value, Constants.UNITS_MINUTES)

    @staticmethod
    def addSeconds(date_time, value):
        """ Adds given number of seconds to the date/datetime provided.
        :param date_time: input for date/datetime.
        :return: date/datetime
        """
        return DateTime._updateDateTime(date_time, value, Constants.UNITS_SECONDS)

    @staticmethod
    def _updateDateTime(date_time, value, units):
        """ Updates date/datetime with given duration as per the units provided.
        :param date_time: input for date/datetime
        :param value: input for duration for add/sub.
        :param units: units for relative delta
        :return: date/datetime.
        """
        if units == Constants.UNITS_YEARS:
            return date_time + relativedelta(years=+value)
        elif units == Constants.UNITS_MONTHS:
            return date_time + relativedelta(months=+value)
        elif units == Constants.UNITS_WEEKS:
            return date_time + relativedelta(weeks=+value)
        elif units == Constants.UNITS_DAYS:
            return date_time + relativedelta(days=+value)
        elif units == Constants.UNITS_HOURS:
            return date_time + relativedelta(hours=+value)
        elif units == Constants.UNITS_MINUTES:
            return date_time + relativedelta(minutes=+value)
        else:
            return date_time + relativedelta(seconds=+value)

    @staticmethod
    def dateInYears(date_time):
        """ This function returns the date in years from the epoch date January 1, 1970
            to the given DATE or timestamp, as a real number.
        :rtype : float
        :param date_time: input for date/datetime
        :return: years
        """
        return DateTime._convertToUnits(date_time, DateTime._S_PER_YR)

    @staticmethod
    def dateInMonths(date_time):
        """ This function returns the date in months from the epoch date January 1, 1970
            to the given DATE or timestamp, as a real number.
        :rtype : float
        :param date_time: input for date/datetime
        :return: months
        """
        return DateTime._convertToUnits(date_time, DateTime._S_PER_MONTH)

    @staticmethod
    def dateInWeeks(date_time):
        """ This function returns the date in weeks from the epoch date January 1, 1970
            to the given DATE or timestamp, as a real number.
        :rtype : float
        :param date_time: input for date/datetime
        :return: weeks
        """
        return DateTime._convertToUnits(date_time, DateTime._S_PER_WEEK)

    @staticmethod
    def dateInDays(date_time):
        """ This function returns the date in days from the epoch date January 1, 1970
            to the given DATE or timestamp, as a real number.
        :rtype : float
        :param date_time: input for date/datetime
        :return: days
        """
        return DateTime._convertToUnits(date_time, DateTime._S_PER_DAY)

    @staticmethod
    def _convertToUnits(date_time, unit_ms):
        l_date_time = date_time
        if type(date_time) is date:
            l_date_time = datetime.combine(date_time, datetime.min.time())
        total_secs = cal.timegm(datetime.timetuple(l_date_time))
        if total_secs >= Constants.NUM_ZERO:
            total_secs = DateTime._S_PER_DAY * (total_secs / DateTime._S_PER_DAY)
        else:
            total_secs = DateTime._S_PER_DAY * \
                         ((total_secs + Constants.NUM_ONE - DateTime._S_PER_DAY) / DateTime._S_PER_DAY)

        return float(Constants.FLOAT_FMT % (Decimal(str(total_secs)) / Decimal(str(unit_ms))))

    @staticmethod
    def __getTimeMillis(date_time):
        time_struct = gmtime(date_time)
        return (time_struct.tm_hour * 60 * 60 + time_struct.tm_min * 60 + time_struct.tm_sec) * 1000

    @staticmethod
    def timeInHours(duration):
        """
        Normalizes the input time in seconds and returns the hour of day equivalent.
        :return: hour of the day
        """
        if duration > DateTime._MAX_CF_SECONDS or duration < DateTime._MIN_CF_SECONDS or \
            math.isnan(duration):
            return float('nan')
        else:
            hours_in_day = float(DateTime.__getTimeMillis(duration)) / float(DateTime._MS_PER_HR)
            if hours_in_day >= 0:
                return hours_in_day
            else:
                return 24.0 + hours_in_day

    @staticmethod
    def timeInMinutes(duration):
        """

        :param duration:
        :return: minute of the day
        """
        if duration > DateTime._MAX_CF_SECONDS or duration < DateTime._MIN_CF_SECONDS or \
            math.isnan(duration):
            return float('nan')
        else:
            minutes_in_day = float(DateTime.__getTimeMillis(duration)) / float(DateTime._MS_PER_MIN)
            if minutes_in_day >= 0:
                return minutes_in_day
            else:
                return 1440 + minutes_in_day

    @staticmethod
    def timeInSeconds(duration):
        """

        :param duration:
        :return:
        """
        if math.isnan(duration):
            return -1
        else:
            seconds = duration % (DateTime._MS_PER_DAY / 1000)
            if seconds >= 0:
                return long(seconds)
            else:
                return long((DateTime._MS_PER_DAY / 1000) + seconds)

    @staticmethod
    def minutesDifference(d1, d2, rollover):
        if not rollover or d2 >= d1:
            return (d2 - d1) * 1000 / DateTime._MS_PER_MIN
        else:
            return 24.0 * 60.0 - (d1 * 1000) / DateTime._MS_PER_MIN + \
                   d2 * 1000 / DateTime._MS_PER_MIN

    @staticmethod
    def secondsDifference(d1, d2, rollover):
        if not rollover or d2 >= d1:
            return round((d2 - d1) * 100000) / 100000
        else:
            return round((24.0 * 60.0 * 60.0 - d1 + d2) * 100000) / 100000

    @staticmethod
    def hoursDifference(d1, d2, rollover):
        if math.isnan(d1) or math.isnan(d2):
            return float('nan')
        elif not rollover or d2 >= d1:
            return (d2 - d1) * 1000 / DateTime._MS_PER_HR
        else:
            return ((DateTime._MS_PER_DAY / 1000) - d1 + d2) * 1000 / DateTime._MS_PER_HR

    @staticmethod
    def daysDifference(date_time1, date_time2):
        """ This function identifies the number of days that separate Date1/DateTime1 and Date2/DateTime2.
            If Date1/DateTime1 occurs before Date2/DateTime2, the result will be positive.
            Otherwise, the value will be negative.
        :rtype : float
        :param date_time1: input for date1/datetime1
        :param date_time2: input for date2/datetime2
        :return: number of days
        """
        return DateTime._getDiffInUnits(date_time1, date_time2, DateTime._S_PER_DAY, Constants.UNITS_DAYS)

    @staticmethod
    def weeksDifference(date_time1, date_time2):
        """ This function identifies the number of weeks that separate Date1/DateTime1 and Date2/DateTime2.
            If Date1/DateTime1 occurs before Date2/DateTime2, the result will be positive.
            Otherwise, the value will be negative.
        :rtype : float
        :param date_time1: input for date1/datetime1
        :param date_time2: input for date2/datetime2
        :return: number of weeks
        """
        return DateTime._getDiffInUnits(date_time1, date_time2, DateTime._S_PER_WEEK, Constants.UNITS_WEEKS)

    @staticmethod
    def yearsDifference(date_time1, date_time2):
        """ This function identifies the number of years that separate Date1/DateTime1 and Date2/DateTime2.
            If Date1/DateTime1 occurs before Date2/DateTime2, the result will be positive.
            Otherwise, the value will be negative.
        :rtype : float
        :param date_time1: input for date1/datetime1
        :param date_time2: input for date2/datetime2
        :return: number of years
        """
        return DateTime._getDiffInUnits(date_time1, date_time2, DateTime._S_PER_YR, Constants.UNITS_YEARS)

    @staticmethod
    def _getDiffInUnits(date_time1, date_time2, units_secs, units):
        l_date_time1 = date_time1
        l_date_time2 = date_time2

        if type(date_time1) is date:
            l_date_time1 = datetime.combine(date_time1, datetime.min.time())
        if type(date_time2) is date:
            l_date_time2 = datetime.combine(date_time2, datetime.min.time())

        total_secs = (l_date_time2 - l_date_time1).total_seconds()

        return float(Constants.FLOAT_FMT % (Decimal(str(total_secs)) / Decimal(str(units_secs))))

    @staticmethod
    def dateBefore(dateTime1,dateTime2):
        """
        :param dateTime1: Input for dateTime-1
        :param dateTime2: Input for dateTime-2
        :return: True if dateTime1 < dateTime2 otherwise false
        """
        if dateTime1 < dateTime2:
            return True
        else:
            return False

    @staticmethod
    def timeBefore(time1,time2):
        """
        :param time1: Input for Time-1
        :param time2: Input for Time-2
        :return: True if time1 < time2 otherwise false
        """
        if time1 < time2:
            return True
        else:
            return False

    @staticmethod
    def monthsDifference(dateTime1,dateTime2):
        """
        Returns number of months difference between 2 given timesamps
        :param dateTime1: Input for dateTime-1
        :param dateTime2: Input for dateTime-2
        :return: Int
        """
        diffTime = dateTime1 - dateTime2
        return diffTime.days/30

    @staticmethod
    def day(dateObj):
        """
        Returns the date value present in given date object
        :param dateObj: Input for the date object
        :return: Int
        """
        if isinstance(dateObj,date):
            return dateObj.day
        else:
            return -1

    @staticmethod
    def month(dateObj):
        """
        Returns the month value present in given date object
        :param dateObj: Input for the date object
        :return: Int
        """
        if isinstance(dateObj,date):
            return dateObj.month
        else:
            return -1

    @staticmethod
    def year(dateObj):
        """
        Returns the year value present in given date object
        :param dateObj: Input for the date object
        :return: Int
        """
        if isinstance(dateObj,date):
            return dateObj.year
        else:
            return -1
# Commenting out as there is no support for zero argument UDFs in spark
    # @staticmethod
    # def now():
    #     """
    #     Returns the current date and time
    #     :return: datetime
    #     """
    #     cTime = datetime.now()
    #     return cTime

    @staticmethod
    def dayName(dateObj,short=False):
        """
        Returns the day name either in Short or Long format for given date object
        :param dateObj: Input for the date object
        :param short: Short Format or Long Format, default is Long Format
        :return: String
        """
        if isinstance(dateObj,date):
            wkDay = cal.weekday(dateObj.year,dateObj.month,dateObj.day)
            daysLong = cal.day_name
            daysAbbr = cal.day_abbr

            if short:
                return daysAbbr[wkDay]
            else:
                return daysLong[wkDay]
        else:
            return -1

    @staticmethod
    def monthName(dateObj,short=False):
        """
        Returns the month name either in Short or Long format for given date object
        :param dateObj: Input for the date object
        :param short: Short Format or Long Format, default is Long Format
        :return: String
        """
        if isinstance(dateObj,date):
            monthsLong = cal.month_name
            monthsAbbr = cal.month_abbr

            if short:
                return monthsAbbr[dateObj.month]
            else:
                return monthsLong[dateObj.month]
        else:
            return -1

    @staticmethod
    def weekdayName(dayValue,short=False):
        """
        Returns the day name either in Short or Long format for given day value
        :param dayValue: Input for the day value
        :param short: Short Format or Long Format, default is Long Format
        :return: String
        """
        if dayValue >=0 and dayValue < 7:
            daysLong = cal.day_name
            daysAbbr = cal.day_abbr

            if short:
                return daysAbbr[dayValue]
            else:
                return daysLong[dayValue]
        else:
            return -1
