"""
Contains Miscellaneous functions implementations for Python
"""

class Misc:
    def __init__(self):
        pass

    @staticmethod
    def blankOut(anyThing):
        """blankOut returns none type for any given input
        :rtype None
        :param anyThing - Any type of input value """

        return None

