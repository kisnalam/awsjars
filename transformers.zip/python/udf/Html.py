from bs4 import BeautifulSoup
from MarkupBase import *


class Html(MarkupBase):

    @staticmethod
    def __loadRoot(markup):
        return BeautifulSoup(markup, "html.parser")

    @staticmethod
    def htmlExtractTag(content, tag, number=1):
        """
        :param content: HTML content as String
        :param tag: Tag name
        :param number: Occurrence of the tag
        :return: Returns the specified fragment of the content that matches the specified HTML tag,
        plus the tag element.
        """
        return MarkupBase.extractTag(Html.__loadRoot(content), tag, number)

    @staticmethod
    def htmlTagValue(element):
        """
        :param element: Element of a HTML
        :return: Returns the child value (all content between the tags) of the specified HTML tag
        element.
        """
        return MarkupBase.tagValue(Html.__loadRoot(element), element)

    @staticmethod
    def htmlExtractTags(content, tag):
        """
        :param content: HTML content as String
        :param tag: Tag name
        :return: Returns all of the fragments of the content matching the specified HTML tag, plus
        the tag element itself.
        """
        return MarkupBase.extractTags(Html.__loadRoot(content), tag)

    @staticmethod
    def htmlAttrValue(element, attr):
        """
        :param element: Element of the HTML
        :param attr: Attribute name of the element
        :return: Returns the value of the specified attribute in the given XML tag element.
        """

        return MarkupBase.attrValue(Html.__loadRoot(element), element, attr)

    @staticmethod
    def htmlRemoveMarkup(content):
        """
        :param content: HTML content as String
        :return: Removes the HTML markup from the body of the provided HTML content.
        """
        text = Html.__loadRoot(content).find_all("body")[0].get_text()

        # break into lines and remove leading and trailing space on each
        lines = (line.strip() for line in text.splitlines())
        # break multi-headlines into a line each
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        # drop blank lines
        text = '\n'.join(chunk for chunk in chunks if chunk)

        return text
