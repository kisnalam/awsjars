import math

class List:

    @staticmethod
    def countEqual(list, value):
        """
        Given a list of numeric and non-numeric elements, find the count of occurrences of a value
        in the list. If the value supplied is null, 0 will be returned.
        :param list: Input list of any data type
        :param value: The value of which occurrences need to be counted
        :rtype Count of occurrences of supplied value in the list
        """
        count = 0
        if value is not None:
            for element in list:
                if (isinstance(element, str) and isinstance(value, str)
                            and element == value) or (List.__is_number_type(element)
                            and List.__is_number_type(value) and element == value):
                    count += 1
        return count

    @staticmethod
    def countGreaterThan(list, value):
        """
        Given a list of numeric and non-numeric elements, find the count of occurrences of values
        greater than the supplied one. If the value supplied is null, 0 will be returned.
        :param list: Input list of any data type
        :param value: The value of which the greater value occurrences need to be counted
        :return: Count of occurrences of values greater than the supplied value present in the list
        """
        count = 0
        if value is not None:
            for element in list:
                if (isinstance(element, str) and isinstance(value, str)
                            and element > value) or (List.__is_number_type(element)
                            and List.__is_number_type(value) and element > value):
                    count += 1
        return count

    @staticmethod
    def countLessThan(list, value):
        """
        Given a list of numeric and non-numeric elements, find the count of occurrences of values
        less than the supplied one. If the value supplied is null, 0 will be returned.
        :param list: Input list of any data type
        :param value: The value of which the lesser value occurrences need to be counted
        :return: Count of occurrences of values lesser than the supplied value present in the list
        """
        count = 0
        if value is not None:
            for element in list:
                if (isinstance(element, str) and isinstance(value, str)
                            and element < value) or (List.__is_number_type(element)
                            and List.__is_number_type(value) and element < value):
                    count += 1
        return count

    @staticmethod
    def countNotEqual(list, value):
        """
        Given a list of numeric and non-numeric elements, find the count of occurrences of values
        not equal to the supplied one. If the value supplied is null, 0 will be returned.
        :param list: Input list of any data type
        :param value: The value of which the not-equal value occurrences need to be counted
        :return: Count of occurrences of values not equal to the supplied value present in the list
        """
        count = 0
        if value is not None:
            for element in list:
                if element == None or (isinstance(element, str) and isinstance(value, str)
                            and element != value) or (List.__is_number_type(element)
                            and List.__is_number_type(value) and element != value):
                    count += 1
        return count

    @staticmethod
    def __is_number_type(value):
        if isinstance(value, int) or isinstance(value, float) or isinstance(value, long):
            return True
        else:
            return False

    @staticmethod
    def countNulls(list):
        """
        Given a list of numeric and non-numeric elements, find the count of occurrences of null
        values.
        :param list: Input list of any data type
        :return: Count of occurrences of null values present in the list
        """
        count = 0
        for element in list:
            if element is None:
                count += 1
        return count

    @staticmethod
    def countNotNulls(list):
        """
        Given a list of numeric and non-numeric elements, find the count of occurrences of
        non-null values.
        :param list: Input list of any data type
        :return: Count of occurrences of non-null values present in the list
        """
        count = 0
        for element in list:
            if element is not None:
                count += 1
        return count

    @staticmethod
    def firstIndex(list, value):
        """
        Find the index of first occurrence of given element in the list of numeric and
        non-numeric values
        :param list: Input list of any data type
        :param value: The value for which first index need to be found
        :return: Index of the first occurrence of given value
        """
        try:
            index_val = list.index(value)
        except ValueError:
            index_val = -1
        return index_val

    @staticmethod
    def firstNonNull(list):
        """
        Find the first non-null element present in given list
        :param list: Input list of any data type
        :return: First non-null value present in the given list
        """
        for index in range(len(list)):
            if list[index] is not None:
                return list[index]
        return None

    @staticmethod
    def firstNonNullIndex(list):
        """
        Find the index of the first non-null element present in given list
        :param list: Input list of any data type
        :return: Index of first non-null value present in the given list
        """
        for index in range(len(list)):
            if list[index] is not None:
                return index
        return -1

    @staticmethod
    def lastIndex(list, value):
        """
        Find the index of last occurrence of given element in the list of numeric and
        non-numeric values
        :param list: Input list of any data type
        :param value: The value for which last index need to be found
        :return: Index of the last occurrence of given value
        """
        try:
            index_val = len(list) - 1 - list[::-1].index(value)
        except ValueError:
            index_val = -1
        return index_val

    @staticmethod
    def lastNonNull(list):
        """
        Find the last non-null element present in given list
        :param list: Input list of any data type
        :return: Last non-null value present in the given list
        """
        for index in range(len(list)):
            if list[-(index + 1)] is not None:
                return list[-(index + 1)]
        return None

    @staticmethod
    def lastNonNullIndex(list):
        """
        Find the index of the last non-null element present in given list
        :param list: Input list of any data type
        :return: Index of last non-null value present in the given list
        """
        for index in range(len(list)):
            if list[-(index + 1)] is not None:
                return len(list) - index - 1
        return -1

    @staticmethod
    def maxN(list):
        """
        Given a list of numeric and non-numeric values, find the maximum numeric value
        :param list: Input list of any data type
        :return: Maximum numeric value present in the list
        """
        return List.__minmax_n(list, lambda x, y: x < y)

    @staticmethod
    def minN(list):
        """
        Given a list of numeric and non-numeric values, find the minimum numeric value
        :param list: Input list of any data type
        :return: Minimum numeric value present in the list
        """
        return List.__minmax_n(list, lambda x, y: x > y)

    @staticmethod
    def __minmax_n(list, func):
        val = float('nan')
        for element in list:
            if isinstance(element, int) or isinstance(element, float) \
                    or isinstance(element, long):
                if math.isnan(val) or func(val, element):
                    val = element
        return val
