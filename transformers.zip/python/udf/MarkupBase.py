class MarkupBase:
    """ Implements common methods from xml and html."""

    @staticmethod
    def extractTag(root, tag, occurrence=1):
        tags = root.find_all(tag)

        if len(tags) < occurrence or occurrence < 1:
            return None
        else:
            return str(tags[occurrence - 1])

    @staticmethod
    def tagValue(root, element):
        tagname = MarkupBase.__getTagName(element)
        tag = root.find_all(tagname)[0]
        li = tag.contents

        ret = []
        for l in li:
            ret.append(str(l))

        text = ''.join(ret)

        # break into lines and remove leading and trailing space on each
        lines = (line.strip() for line in text.splitlines())
        # break multi-headlines into a line each
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        # drop blank lines
        text = '\n'.join(chunk for chunk in chunks if chunk)

        return text

    @staticmethod
    def extractTags(root, tag):
        tags = root.find_all(tag)
        str_tags = []

        for tag in tags:
            str_tags.append(str(tag))
        return str_tags

    @staticmethod
    def attrValue(root, element, attr):
        tagname = MarkupBase.__getTagName(element)
        tag = root.find_all(tagname)[0]
        value = tag.get(attr)
        if value is None:
            value = ""
        return value

    @staticmethod
    def __getTagName(element):
        tagname = element[1:]
        tagname = tagname.split()[0]
        index = tagname.find(">")
        if index != -1:
            tagname = tagname[:index]
        if tagname.endswith("/"):
            tagname = tagname[:len(tagname) - 1]
        return tagname
