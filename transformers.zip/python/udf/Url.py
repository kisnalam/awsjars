import requests
import urlparse


class Url:

    @staticmethod
    def __parsedUrl(surl):
        return urlparse.urlparse(surl)

    @staticmethod
    def urlFragment(surl):
        """
        :param surl: URL
        :return: Provides the fragment portion of the specified URL. This method returns an empty
        text string if the URL does not contain a fragment.
        """
        return Url.__parsedUrl(surl).fragment

    @staticmethod
    def urlHost(surl):
        """
        :param surl: URL
        :return: Provides the host portion of the specified URL.
        """
        return Url.__parsedUrl(surl).hostname

    @staticmethod
    def urlPath(surl):
        """
        :param surl: URL
        :return: Provides the path portion of the specified URL.
        """
        return Url.__parsedUrl(surl).path

    @staticmethod
    def urlPort(surl):
        """
        :param surl: URL
        :return: Provides the port number of the specified URL. This parameter returns the default
        port number that is based on the scheme if a port is not explicitly specified.
        """
        port = Url.__parsedUrl(surl).port
        return port if port is not None else -1

    @staticmethod
    def urlQuery(surl):
        """
        :param surl: URL
        :return: Provides the query string of the specified URL.
        """
        return Url.__parsedUrl(surl).query

    @staticmethod
    def urlParam(surl, name):
        """
        :param surl: URL
        :param name: Parameter name
        :return: Provides the value of the specified parameter from the specified URL. This
        parameter returns an empty text string if the URL does not contain the parameter.
        """
        try:
            param = urlparse.parse_qs(Url.__parsedUrl(surl).query)[name][0]
        except KeyError:
            param = ""
        return param

    @staticmethod
    def urlScheme(surl):
        """
        :param surl: URL
        :return: Provides the scheme, or protocol, of the specified URL.
        """
        return Url.__parsedUrl(surl).scheme

    @staticmethod
    def urlGet(surl):
        """
        :param surl: URL
        :return: Gets the content, content type, and content length of the provided URL.
        """
        r = requests.get(surl)
        content = r.content
        mimetype = r.headers["content-type"]
        return content, mimetype, len(content)

    @staticmethod
    def urlGetHeader(surl):
        """
        :param surl: URL
        :return: Gets the header values of the URL provided.
        """
        headers = requests.get(surl).headers
        ret = ""

        for key, value in headers.iteritems():
            ret += str(key) + ": " + str(value)
        return ret

    @staticmethod
    def urlGetContent(surl):
        """
        :param surl: URL
        :return: Gets the content of the URL provided.
        """
        r = requests.get(surl)
        content = r.content
        return content
