from bs4 import BeautifulSoup
from MarkupBase import *


class Xml(MarkupBase):

    @staticmethod
    def __loadRoot(markup):
        return BeautifulSoup(markup, "xml")

    @staticmethod
    def xmlExtractTag(content, tag, number=1):
        """
        :param content: XML content as String
        :param tag: Tag name
        :param number: Occurrence of the tag
        :return: Returns the specified fragment of the content that matches the specified XML tag,
        plus the tag element itself.
        """
        return MarkupBase.extractTag(Xml.__loadRoot(content), tag, number)

    @staticmethod
    def xmlTagValue(element):
        """
        :param element: Element of then XML
        :return: Returns the child value (all content between the tags) of the specified XML tag
        element.
        """
        return MarkupBase.tagValue(Xml.__loadRoot(element), element)

    @staticmethod
    def xmlExtractTags(content, tag):
        """
        :param content: XML content as String
        :param tag: Tag name
        :return: Returns all of the fragments of the content that matches the specified XML tag,
        plus the tag element itself.
        """
        return MarkupBase.extractTags(Xml.__loadRoot(content), tag)

    @staticmethod
    def xmlAttrValue(element, attr):
        """
        :param element: Element of a XML
        :param attr: Attribute name of the element
        :return: Returns the value of the specified attribute in the given XML tag element.
        """
        return MarkupBase.attrValue(Xml.__loadRoot(element), element, attr)
