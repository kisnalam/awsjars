import re
import soundex
import hashlib

from Constants import Constants


class String:
    _startStr = "START_STRING"
    _endStr = "END_STRING"

    def __init__(self):
        pass

    @staticmethod
    def validText(text):
        """Returns false if the text is None else returns true
        :param text: input string
        :rtype : returns boolean
        """
        if text is None:
            return False
        else:
            return True

    @staticmethod
    def allButFirst(text, truncLength):
        """Truncates truncLength characters from start of text.
        :param text: input string
        :rtype : returns truncated string
        """
        if String.validText(text) and not (truncLength > len(text) or truncLength < 0):
            return text[-truncLength:]
        else:
            return None

    @staticmethod
    def allButLast(text, truncLength):
        """Truncates truncLength characters from end of text.
        :param text: input string
        :rtype : returns truncated string
        """
        if String.validText(text) and not (truncLength > len(text) or truncLength < 0):
            return text[:truncLength]
        else:
            return None

    @staticmethod
    def wordCount(text):
        """Counts the individual words from the provided text.
        :param text: input for word count
        :rtype : int
        :return: number of word in the input provided.
        """
        if text is None or text == str():
            return Constants.NUM_ZERO
        else:
            words = re.split(Constants.REGEX_WORD_DELIMITER, text)
            if len(words) > Constants.NUM_ZERO and words[Constants.NUM_ZERO] == str():
                # split function returns an empty string in the result if
                # the delimiter is encountered in the beginning of the string,
                # it should not be included in the word count.
                return len(words) - Constants.NUM_ONE
            else:
                return len(words)

    @staticmethod
    def endString(text, count):
        """Returns the right-most characters of the given text.
        :param text: input for end string
        :param count: input for number of characters.
        :rtype : String
        """
        return String._getSubString(text, count, String._endStr)

    @staticmethod
    def startString(text, count):
        """Returns the left-most characters of the given text.
        :param text: input for start string
        :param count: input for number of characters
        :rtype : String
        """
        return String._getSubString(text, count, String._startStr)

    @staticmethod
    def _getSubString(text, count, extract_part):
        if text is None or text == str() or count <= Constants.NUM_ZERO:
            return None
        elif count >= len(text):
            return text
        elif extract_part == String._startStr:
            return text[Constants.NUM_ZERO:count]
        else:
            return text[len(text) - count:len(text)]

    @staticmethod
    def clean(text):
        """Removes all non-printable ASCII characters with string from the given text.
        :param text: input for clean
        :rtype : string
        """
        if text is None:
            return None
        elif text == str():
            return str()
        else:
            return re.sub(Constants.NON_PRINT_CHARS_PY, str(), text)

    @staticmethod
    def patternSliceItem(text, reg_expr, index):
        """ Slices a string based on the regular expression pattern provided. And returns the sliced item
            based on the index provided

        :rtype : string
        :param text: input for pattern slice item.
        :param reg_expr: input for regular expression.
        :param index: input for slice index.
        """
        return String._getStringSegment(text, reg_expr, index)

    @staticmethod
    def sliceItem(text, delimiter, index):
        """ Slices a string based on the delimiter provided. And returns the sliced item based on the
            index provided
        :rtype : string
        :param text: input for slice item.
        :param delimiter: input for delimiter.
        :param index: input for slice index.
        """
        return String._getStringSegment(text, delimiter, index)

    @staticmethod
    def _getStringSegment(text, split_str, index):
        if text is None or split_str is None or text == str() or split_str == str():
            return None
        elif index < Constants.NUM_ONE:
            raise ValueError("Value for index should be greater than 0")
        elif type(index) is not int and type(index) is not long:
            raise TypeError("Value for index should be Integer")
        else:
            return String._getItem(text, split_str, index)

    @staticmethod
    def _getItem(text, reg_expr, index):
        found = False
        result = None
        count = 0
        st_index = 0
        for match in re.finditer(reg_expr, text):
            count += Constants.NUM_ONE
            if count == index:
                result = text[st_index:match.start()]
                found = True
                break
            else:
                st_index = match.end()
        count += Constants.NUM_ONE
        if found:
            return result
        elif count == index:
            result = text[st_index:len(text)]
        else:
            result = None
        return result

    @staticmethod
    def getMatches(text, reg_expr):
        """
        Returns a list of matches for the specified regular expression pattern for the input provided.

        :rtype : list
        :param text: input string
        :param reg_expr: input for regular expression.
        """
        if text is None or reg_expr is None or text == str() or reg_expr == str():
            return None
        else:
            return re.findall(reg_expr, text)

    @staticmethod
    def getMatch(text, reg_expr, occurrence=Constants.NUM_ONE):
        """
        Returns a portion of the text that matches the specified regular expression pattern.
        The number parameter is optional and specifies the occurrence to return (defaults to 1).

        :rtype : string
        :param text: input for get match one
        :param reg_expr: input for regular expression
        :param occurrence: input for occurrence
        """
        if text is None or reg_expr is None or text == str() or reg_expr == str():
            return None
        elif occurrence < Constants.NUM_ONE:
            raise ValueError("Value for occurrence should be greater than 0")
        elif type(occurrence) is not int and type(occurrence) is not long:
            raise TypeError("Value for occurrence should be Integer")
        else:
            matches = re.findall(reg_expr, text)
            if matches is not None and len(matches) > Constants.NUM_ZERO and len(matches) >= occurrence:
                return matches[occurrence - Constants.NUM_ONE]
            else:
                return None

    @staticmethod
    def getGroupMatches(text, reg_expr, group_num):
        """
        Returns every match of the text that matches a grouping
        from the specified regular expression pattern.

        :rtype : list of strings
        :param text: input for extracting group matches
        :param reg_expr: input for regular expression.
        :param group_num: input for group number
        """
        if text is None or reg_expr is None or text == str() or reg_expr == str():
            return None
        elif group_num < Constants.NUM_ZERO:
            raise ValueError("Value for group number should be greater than 0")
        elif type(group_num) is not int and type(group_num) is not long:
            raise TypeError("Value for group number should be Integer")
        else:
            finditer = re.finditer(reg_expr, text)
            result = list()
            for match in finditer:
                if (group_num <= len(match.groups()) or group_num == Constants.NUM_ZERO) and match.group(
                        group_num) != "":
                    result.append(match.group(group_num))
            if len(result) == Constants.NUM_ZERO:
                return None
            else:
                return result

    @staticmethod
    def getGroupMatch(text, reg_expr, group_num, occurrence=Constants.NUM_ONE):
        """
        Returns a portion of the text that matches a grouping from the specified regular
        expression pattern.
        The number parameter is optional and specifies the match occurrence
        from which to return the group (defaults to 1).
        :rtype : string
        :param text: input for extracting group match
        :param reg_expr: input for regular expression
        :param group_num: input for group number
        :param occurrence: input for occurrence
        """
        if text is None or reg_expr is None or reg_expr == str() or text == str():
            return None
        elif group_num < Constants.NUM_ZERO:
            raise ValueError("Value for group number should not be negative")
        elif type(group_num) is not int and type(group_num) is not long:
            raise TypeError("Value for group number should be Integer")
        elif occurrence < Constants.NUM_ONE:
            raise ValueError("Value for occurrence should be greater than 0")
        elif type(occurrence) is not int and type(occurrence) is not long:
            raise TypeError("Value for occurrence should be Integer")
        else:
            finditer = re.finditer(reg_expr, text)
            result = str()
            count = Constants.NUM_ZERO
            for match in finditer:
                count = count + Constants.NUM_ONE
                if count == occurrence:
                    if (group_num <= len(match.groups()) or group_num == Constants.NUM_ZERO) and match.group(
                            group_num) != "":
                        result = match.group(group_num)
                    break
            if result == str():
                return None
            else:
                return result

    @staticmethod
    def substitute(input_str, find_str, replace_str, occurrence):
        """
            Substitutes portions of text with a replacement value within the given text.

        :rtype : string
        :param input_str: input for substitute
        :param find_str: input for find
        :param replace_str: input for replacing the found portion of string.
        :param occurrence: input for occurrence
        """
        if input_str is None or find_str is None or replace_str is None:
            return input_str
        elif occurrence < Constants.NUM_ONE:
            raise ValueError("Value for occurrence should be greater than 0")
        elif type(occurrence) is not int and type(occurrence) is not long:
            raise TypeError("Value for occurrence should be Integer")
        elif find_str in input_str:
            index = str.find(input_str, find_str)
            count = Constants.NUM_ZERO
            while index != -Constants.NUM_ONE:
                count += Constants.NUM_ONE
                if count == occurrence:
                    break
                else:
                    index = str.find(input_str, find_str, index + Constants.NUM_ONE)
            if index == -Constants.NUM_ONE:
                return input_str
            else:
                return input_str[:index] + replace_str + input_str[index + len(find_str):]
        else:
            return input_str

    @staticmethod
    def search(search_term, text, start_index=Constants.NUM_ONE):
        """ Returns the 1-based index of the needle in the haystack(text)
        by searching from the given start index. Unlike FIND, the
        search is case-insensitive and supports ? and * wildcards.
        The search starts from the beginning if the start index is
        omitted. Returns 0 if the haystack does not contain the needle.
        :rtype : int
        :param search_term: input for search term.
        :param text: input for search
        :param start_index: input for search start index
        """
        result = 0
        needle = search_term
        if search_term is None or text is None:
            return None
        elif search_term == str() or text == str():
            return result
        elif start_index <= 0:
            raise ValueError("Value for start index should be greater than 0")
        else:
            needle = needle.replace("\\\\", "\\\\\\\\")
            needle = needle.replace("\\.", "\\\\.")
            needle = needle.replace("\\?", ".")
            needle = needle.replace("\\*", ".*")
            needle = needle.replace("?", ".")
            needle = needle.replace("*", ".*")
            needle = needle.replace("\?", ".")
            needle = needle.replace("\*", ".*")
            needle = needle.replace("([+|()\\[\\]{}])", "\\\\$1")
            pattern = re.compile(needle, re.IGNORECASE)
            match = pattern.search(text, (start_index - Constants.NUM_ONE))

            if match is None:
                return result
            else:
                return match.start() + 1

    @staticmethod
    def slice(text, delimiter):
        """
        Splits a text - either using white space as default delimiter or a supplied delimiter
        Slices a string based on the delimiter provided and returns the slices
        :param text: text to be split
        :param delimiter: delimiter to be used to split the text
        :rtype : Array of sub-strings after splitting the string by delimiter supplied
        """
        if text is None:
            return []
        elif delimiter is None:
            return [text]
        else:
            list = []
            current_str = text
            index = current_str.find(delimiter)
            while index != -1:
                if index > 0:
                    list.append(current_str[0:index].strip())
                current_str = current_str[index + len(delimiter):]
                index = current_str.find(delimiter)

            current_str = current_str.strip()
            if len(current_str) > 0:
                list.append(current_str)
            return list

    @staticmethod
    def patternSlice(text, regex):
        """
        Slices a string based on the regular expression provided and returns the slices
        :param text: Text to split
        :param regex: regular expression to be used to split
        :rtype : Array of sub-strings after splitting the string by delimiter regular expression
        """
        if text is None:
            return []
        elif regex is None:
            return [text]
        else:
            return re.split(regex, text)

    @staticmethod
    def isUpperCode(string):
        """Returns true when input string is uppercase else false
        :rtype Boolean
        :param string: input string to check whether is upper or not"""

        if string is not None:
            return string.isupper()

    @staticmethod
    def isAlphaCode(string):
        """Returns true when input string is alphabet or number else false
        :rtype Boolean
        :param string: input string to check whether is alpha code or not"""

        if string is not None:
            return string.isalnum()

    @staticmethod
    def isNumberCode(string):
        """Returns true when input string is number else false
        :rtype Boolean
        :param string: input string to check whether is number or not"""

        if string is not None:
            return string.isdigit()

    @staticmethod
    def isLowerCode(string):
        """Returns true when input string is all lower case  else false
        :rtype Boolean
        :param string: input string to check whether is lowe case or not"""

        if string is not None:
            return string.islower()

    @staticmethod
    def lastChar(string):
        """Returns last character in the given string char
        :rtype string
        :param string: input string"""

        if string is not None and len(string) > 0:
            return string[-1]

    @staticmethod
    def alphabeticallyBefore(str1, str2):
        """Returns true is str1 comes first compared to str2 alphabetically
        :rtype Boolean
        :param str1: first input string
        :param str2: second input string"""

        if str1 is not None and str2 is not None:
            return str1 < str2

    @staticmethod
    def stripChar(string, ch):
        """Returns string after removing the specified character from input string
        :rtype String
        :param string: input string
        :param ch: character to be removed/stripped"""

        if string is not None and ch is not None:
            return string.replace(ch, "")

    @staticmethod
    def locChar(string, ch, index):
        """Returns location of the character if present in the given string
        :rtype int
        :param string: input string
        :param ch: character to be removed/stripped
        :param index: check for the character from the index mentioned"""

        if string is not None:
            if len(string) == 0:
                return -1
            elif index < 0 or index >= len(string):
                return None
            else:
                return string.find(ch, index)

    @staticmethod
    def locCharBack(string, ch, index):
        """Returns location of the character from back if present in the given string
        :rtype int
        :param string: input string
        :param ch: character to be removed/stripped
        :param index: check for the character from the index mentioned"""

        if string is not None:
            if len(string) == 0:
                return -1
            elif index < 0 or index >= len(string):
                return None
            else:
                return string.rfind(ch, index)

    @staticmethod
    def isSubStringCount(first, second, cnt):
        """Returns the index of the Nth occurrence of First SUBSTRING within the
        specified Second STRING. If there are fewer than N occurrences of SUBSTRING, 0 is returned.
        :rtype int
        :param first: first input string
        :param second: second input string
        :param cnt: no. of substrings"""

        if first is not None and second is not None:
            count = 0
            pos = 0
            while pos >= 0:
                pos = second.find(first, pos)
                if pos >= 0:
                    count += 1
                    if count == cnt:
                        return pos
                    pos += 1
            return -1

    @staticmethod
    def countSubString(first, second):
        """Returns the number of times the specified substring occurs within the string. For example
        :rtype int
        :param first: first input string
        :param second: second input string"""

        if first is not None and second is not None:
            pos = 0
            count = 0
            while 0 <= pos < len(first):
                pos = first.find(second, pos)
                if pos >= 0:
                    pos += 1
                    count += 1
            return count

    @staticmethod
    def hasMidString(first, second):
        """If second is a substring of first but does not start on
        the first character of first or end on the last, then this function returns
        the subscript at which the substring starts. Otherwise, this function returns a value of 0.
        :rtype int
        :param first: first input string
        :param second: second input string"""

        if first is not None and second is not None:
            pos = 0
            last = len(first) - len(second)
            while pos >= 0:
                pos = first.find(second, pos)
                if 0 < pos < last:
                    return pos
                elif pos == -1:
                    return 0
                pos += 1

    @staticmethod
    def hasSubString(first, second, frmIndex):
        """Searches the string STRING, starting from its Nth character,
        for a substring equal to the string SUBSTRING.
        If found, this function returns the integer
        subscript at which the matching substring begins.
        :rtype int
        :param first: first input string
        :param second: second input string"""

        if first is not None and second is not None:
            return first.find(second, frmIndex)

    @staticmethod
    def skipChar(first, ch, pos):
        if first is not None and len(ch) == 1:
            if len(first) == 0:
                return -1
            elif pos <=0 or pos >= len(first):
                return None
            else:
                subStr = first[pos:]
                if subStr.find(ch) < 0:
                    return pos
                else:
                    for i in range(len(subStr)):
                        if ch == subStr[i]:
                            continue
                        else:
                            return i + pos
            return -1

    @staticmethod
    def skipCharBack(first, ch, pos):
        if first is not None and len(ch) == 1:
            if len(first) == 0:
                return -1
            elif pos <= 0 or pos >= len(first):
                return None
            else:
                subStr = first[:pos+1]
                if subStr.rfind(ch) < 0:
                    return pos
                else:
                    for i in range(len(subStr)-1, -1, -1):
                        if ch == subStr[i]:
                            continue
                        else:
                            return i
            return -1

    @staticmethod
    def soundexDifference(firstString,secondString):
        """soundexDifference hashes English strings into alpha-numerical values.
           Strings that sound the same are transformed into the same value.
           Strings that sound the difference are transformed into the different value.
           Returns 0 if both strings are same,
                   1 if strings sound phonetically same,
                   2 if strings are phonetically not same
                   -1 if any one string is invalid

        :rtype int
        :param firstString: First Input string
        :param secondString: Second Input string"""

        if firstString and firstString is not None and \
           secondString and secondString is not None:
            sxInstance = soundex.getInstance()
            return sxInstance.compare(firstString,secondString)
        else:
            return -1

    @staticmethod
    def chomp(string):
        """chomp removes all kinds of whitespaces from the given string and returns the actual string
        :rtype String
        :param string- line of text """

        if string and string is not None:
            return string.strip()
        else:
            return None

    @staticmethod
    def sha1(string):
        """sha1 returns the hex digest for the given string
        :rtype Hex Digest in the form of String
        :param string - Input String """

        if string and string is not None:
            shaObj = hashlib.new('sha1')
            shaObj.update(string.encode('utf-8'))
            return shaObj.hexdigest()
        else:
            return None
