import sys

sys.path.append("C:\\spark-1.6.0-bin-hadoop2.6\\python\\lib\\pyspark.zip")
sys.path.append("C:\\spark-1.6.0-bin-hadoop2.6\\python\\lib\\py4j-0.9-src.zip")
print sys.path





