#!/usr/bin/python

from py4j.protocol import Py4JJavaError, Py4JError
from py4j.java_collections import MapConverter

from pyspark import SparkContext
from pyspark.sql import DataFrame, SQLContext, Column
from pyspark.sql.column import _to_java_column, _to_seq
from pyspark.ml.pipeline import Transformer

_sc = SparkContext._active_spark_context
if _sc:
    _jObject = _sc._jvm.com.ibm.ngpa.rest.transformation.pythonbinding.Transformers
    _to_list = _jObject.toList
    _to_map = _jObject.toScalaMap


# ---------------------------------------------------------------------------
# CustomJavaTransformer
# ---------------------------------------------------------------------------


class CustomJavaTransformer(Transformer):
    def _transform(self, dataset):
        return DataFrame(self._jTransformerObject.transform(dataset._jdf), dataset.sql_ctx)

# ---------------------------------------------------------------------------
# AddColumn --> apply(expr: Column, colname: String)
# ---------------------------------------------------------------------------


class AddColumn(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import AddColumn
    >>> tc = AddColumn(df.score, "new_score")
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """

    def __init__(self, expr, colname):
        try:
            super(AddColumn, self).__init__()
            self._jTransformerObject = _jObject.getAddColumn().apply(_to_java_column(expr), colname)
        except Py4JJavaError:
            print "Error: AddColumn"


# ---------------------------------------------------------------------------
# RenameColumn --> apply(oldname: String, newname: String)
# ---------------------------------------------------------------------------


class RenameColumn(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import RenameColumn
    >>> tc = RenameColumn("id", "new_id")
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """

    def __init__(self, oldname, newname):
        try:
            super(RenameColumn, self).__init__()
            self._jTransformerObject = _jObject.getRenameColumn().apply(oldname, newname)
        except Py4JJavaError:
            print "Error: RenameColumn"


# ---------------------------------------------------------------------------
# Distinct --> apply(cols: String*)
# ---------------------------------------------------------------------------


class Distinct(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()
            
    >>> from pyspark.sql.functions import *
    >>> from Transformers import Distinct
    >>> tc = Distinct("score","id")
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """

    def __init__(self, *cols):
        try:
            super(Distinct, self).__init__()
            self._jTransformerObject = _jObject.getDistinct().apply(_to_seq(_sc, cols))
        except Py4JJavaError:
            print "Error: Distinct"


# ---------------------------------------------------------------------------
# Aggregator --> apply(expr: Column, exprs: Column*)
# ---------------------------------------------------------------------------


class Aggregator(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()
            
    >>> from pyspark.sql.functions import *
    >>> from Transformers import Aggregator
    >>> tc = Aggregator(avg("id"), avg("score"))
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """

    def __init__(self, expr, *exprs):
        try:
            super(Aggregator, self).__init__()
            self._jTransformerObject = _jObject.getAggregator().apply(_to_java_column(expr), _to_seq(_sc, exprs, _to_java_column))
        except Py4JJavaError:
            print "Error: Aggregator"


# ---------------------------------------------------------------------------
# Groupby --> apply(cols: Seq[String], expr: Column, exprs: Column*)
# ---------------------------------------------------------------------------


class Groupby(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()
            
    >>> from pyspark.sql.functions import *
    >>> from Transformers import Groupby
    >>> tc = Groupby(["score","id"], avg("id"), max("id"))
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """

    def __init__(self, cols, expr, *exprs):
        try:
            super(Groupby, self).__init__()
            self._jTransformerObject = _jObject.getGroupby().apply(_to_list(cols), _to_java_column(expr), _to_seq(_sc, exprs, _to_java_column))
        except Py4JJavaError:
            print "Error: Groupby"


# ---------------------------------------------------------------------------
# Cube --> apply(cols: Seq[String], expr: Column, exprs: Column*)
# ---------------------------------------------------------------------------


class Cube(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()
            
    >>> from pyspark.sql.functions import *
    >>> from Transformers import Cube
    >>> tc = Cube(["score","id"], avg("id"), max("id"))
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """

    def __init__(self, cols, expr, *exprs):
        try:
            super(Cube, self).__init__()
            self._jTransformerObject = _jObject.getCube().apply(_to_list(cols), _to_java_column(expr), _to_seq(_sc, exprs, _to_java_column))
        except Py4JJavaError:
            print "Error: Cube"


# ---------------------------------------------------------------------------
# Rollup --> apply(cols: Seq[String], expr: Column, exprs: Column*)
# ---------------------------------------------------------------------------


class Rollup(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import Rollup
    >>> tc = Rollup(["score","id"], avg("id"), max("id"))
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """

    def __init__(self, cols, expr, *exprs):
        try:
            super(Rollup, self).__init__()
            self._jTransformerObject = _jObject.getRollup().apply(_to_list(cols), _to_java_column(expr), _to_seq(_sc, exprs, _to_java_column))
        except Py4JJavaError:
            print "Error: Rollup"


# ---------------------------------------------------------------------------
# Project --> apply(flag: String, col: String, cols: String*)
# ---------------------------------------------------------------------------

class Project(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()
            
    >>> from pyspark.sql.functions import *
    >>> from Transformers import Project
    >>> tc = Project("select","id","score")
    >>> df_result = tc.transform(df)
    >>> df_result.show()

    >>> tc = Project("remove","id")
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """

    def __init__(self, flag, col, *cols):
        try:
            super(Project, self).__init__()
            self._jTransformerObject = _jObject.getProject().apply(flag, col, _to_seq(_sc, cols))
        except Py4JJavaError:
            print "Error: Project"


# ---------------------------------------------------------------------------
# Sort --> apply(sortexpr: Map[String, String])
# ---------------------------------------------------------------------------

class Sort(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()
            
    >>> from pyspark.sql.functions import *
    >>> from Transformers import Sort
    >>> tc = Sort({"id":"desc", "score":"asc"})
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """

    def __init__(self, sortexpr):
        try:
            jSortexpr = MapConverter().convert(sortexpr, _sc._jvm._gateway_client)

            super(Sort, self).__init__()
            self._jTransformerObject = _jObject.getSort().apply(_to_map(jSortexpr))
        except Py4JJavaError:
            print "Error: Sort"


# ---------------------------------------------------------------------------
# Filter  --> def apply(ConditionExpr: String): Filter
# ---------------------------------------------------------------------------

class Filter(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import Filter
    >>> tc = Filter("id<3")
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """
    def __init__(self, conditionExpr):
        try:
            super(Filter, self).__init__()
            self._jTransformerObject = _jObject.getFilter().apply(conditionExpr)
        except Py4JJavaError:
            print "Error: Filter"


# ---------------------------------------------------------------------------
# Limit  --> def apply(Size: Int): Limit
# ---------------------------------------------------------------------------

class Limit(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import Limit
    >>> tc = Limit(5)
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """
    def __init__(self, size):
        try:
            super(Limit, self).__init__()
            self._jTransformerObject = _jObject.getLimit().apply(size)
        except Py4JJavaError:
            print "Error: Limit"


# ---------------------------------------------------------------------------
# Sample  --> def apply(withReplacement: Boolean, SamplingRatio: Float,
#                       SamplingSize: Int, SamplingSeed: Long) : Sample
#         --> def apply(): Sample
# ---------------------------------------------------------------------------

class Sample(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import Sample
    >>> tc = Sample()
    >>> df_result = tc.transform(df)
    >>> df_result.show()

    >>> tc = Sample(True,2)
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """
    def __init__(self, withReplacement=True, samplingRatio=1, samplingSize=-1, samplingSeed=-1):
        try:
            super(Sample, self).__init__()

            self._jTransformerObject = _jObject.getSample().apply(withReplacement,
                                                                  float(samplingRatio),
                                                                  samplingSize,
                                                                  long(samplingSeed))
        except Py4JJavaError:
            print "Error: Sample"

# ---------------------------------------------------------------------------
# NaDrop  --> def apply(mincols: Int = -1, cols: Seq[String] = Seq.empty): NaDrop
#         --> def apply(how: String): NaDrop
#         --> def apply(how: String, cols: Seq[String]): NaDrop
# ---------------------------------------------------------------------------

class NaDrop(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import NaDrop
    >>> tc = NaDrop()
    >>> df_result = tc.transform(df)
    >>> df_result.show()

    >>> tc = ("all", 1, ["id"])
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """
    def __init__(self, how="any", mincols=None, cols=[]):
        try:
            super(NaDrop, self).__init__()

            if mincols is None:
                mincols = -1 if how == "any" else 1

            self._jTransformerObject = _jObject.getNaDrop().apply(mincols, _to_list(cols))
        except Py4JJavaError:
            print "Error: NaDrop"


class Partition(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import Partition
    >>> tc = Partition()
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """
    def __init__(self, col=None, seed=0):
        try:
            super(Partition, self).__init__()

            self._jTransformerObject = _jObject.getPartition().apply(col, seed)
        except Py4JJavaError:
            print "Error: Partition"



# ---------------------------------------------------------------------------
# KTopElements  --> apply(columnName: String, k: Int = 1)
# ---------------------------------------------------------------------------

class KTopElements(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import KTopElements
    >>> tc = KTopElements("score",3)
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """
    def __init__(self, columnName, k):
        try:
            self._jTransformerObject = _jObject.getKTopElements().apply(columnName, k)
        except Py4JJavaError:
            print "Error: KTopElements"

# ---------------------------------------------------------------------------
# KFrequentElements  --> apply(columnName: String, k: Int = 1)
# ---------------------------------------------------------------------------

class KFrequentElements(CustomJavaTransformer):
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import KTopElements
    >>> tc = KFrequentElements("score",3)
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """
    def __init__(self, columnName, k):
        try:
            self._jTransformerObject = _jObject.getKFrequentElements().apply(columnName, k)
        except Py4JJavaError:
            print "Error: KFrequentElements"


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# ----------- Classes NOT extended from spark ml Transformer class ----------
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Except  -->
# ---------------------------------------------------------------------------


class Except:
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import Except
    >>> tc = Except()
    >>> df_result = tc.transform(df, df)
    >>> df_result.show()

    >>> tc = Except("id")
    >>> df_result = tc.transform(df)
    >>> df_result.show()
    """
    def __init__(self, onColumn=""):
        try:
            self._jTransformerObject = _jObject.getExcept().apply(onColumn)
        except Py4JJavaError:
            print "Error: Except"

    def transform(self, dataset1, dataset2):
        return DataFrame(self._jTransformerObject.transform(dataset1._jdf, dataset2._jdf),
                         dataset1.sql_ctx)

# ---------------------------------------------------------------------------
# Intersect  -->
# ---------------------------------------------------------------------------


class Intersect:
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import Intersect
    >>> tc = Intersect()
    >>> df_result = tc.transform(df, df)
    >>> df_result.show()
    """
    def __init__(self):
        try:
            self._jTransformerObject = _jObject.getIntersect().apply()
        except Py4JJavaError:
            print "Error: Intersect"

    def transform(self, dataset1, dataset2):
        return DataFrame(self._jTransformerObject.transform(dataset1._jdf, dataset2._jdf),
                         dataset1.sql_ctx)


# ---------------------------------------------------------------------------
# Union  -->
# ---------------------------------------------------------------------------


class Union:
    """
    >>> rdd = sc.parallelize([(0,1), (0,1), (0,2), (1,2), (1,10), (1,20), (3,18), (3,18), (3,18)])
    >>> df = sqlContext.createDataFrame(rdd, ["id", "score"])
    >>> df.show()

    >>> from pyspark.sql.functions import *
    >>> from Transformers import Union
    >>> tc = Union()
    >>> df_result = tc.transform(df, df)
    >>> df_result.show()

    >>> tc = Union(False)
    >>> df_result = tc.transform(df, df)
    >>> df_result.show()
    """
    def __init__(self, isUnionAll=True):
        try:
            self._jTransformerObject = _jObject.getUnion().apply(isUnionAll)
        except Py4JJavaError:
            print "Error: Union"

    def transform(self, dataset1, dataset2):
        return DataFrame(self._jTransformerObject.transform(dataset1._jdf, dataset2._jdf),
                         dataset1.sql_ctx)


# ---------------------------------------------------------------------------
# Join  --> apply(joinType : String = "inner", expr: ((DataFrame, DataFrame) => Column ) = null)
# ---------------------------------------------------------------------------
