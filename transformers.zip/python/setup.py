from setuptools import setup

setup(name='ibm-transformers',
      version='0.1',
      description='Transformation library for NGWB',
      url='https://github.ibm.com/Analytics/platform-transformation/',
      author='IBM',
      author_email='ibm@ibm.com',
      license='IBM',
      packages=['transformers','udf'],
      zip_safe=False)
